//
//  MainMenuLayer.h
//  catchCoco
//
//  Created by Mac on 14.04.12.
//  Copyright 2012 spotGames. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MainMenuLayer : CCLayer {
    
}

+(CCScene *) scene;

@end
