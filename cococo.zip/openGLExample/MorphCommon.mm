
#import "MorphCommon.h"

AnimationFrame AFrame(float time, float angle)
{
    AnimationFrame frame;
    frame.time = time;
    frame.angle = angle;
    
    return frame;
}