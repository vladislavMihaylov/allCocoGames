#import "MorphGameConfig.h"

NSInteger typeCharacter = 0;
BOOL ICanJump = YES;
BOOL IsMoveRight = YES;
BOOL IsMoveUp = NO;
BOOL IsMoveDown = NO;
BOOL ItsNewGround = NO;

BOOL INeedNextAction = NO;
BOOL IsMorphGameActive = NO;